export type Turn = { role: 'user' | 'assistant'; content: string };

export type AiSettings = { apiKey: string; baseUrl: string; model: string };

export const DEFAULT_BASE_URL = 'https://api.openai.com/v1';
export const DEFAULT_MODEL = 'gpt-4o-mini';

const SYSTEM_PROMPT =
  'You are Aria, a warm, capable AI assistant. Answer questions clearly and helpfully, ' +
  'help with tasks step by step, and keep a natural conversational tone. Use short ' +
  'paragraphs. If you are unsure, say so instead of inventing facts.';

function describeHttpError(status: number, body: string): string {
  if (status === 401 || status === 403) {
    return 'Your API key was rejected. Open Settings and check the key.';
  }
  if (status === 404) {
    return 'Endpoint not found. Check the base URL and the model name in Settings.';
  }
  if (status === 429) {
    return 'Rate limit or no credit on this key. Try again in a moment.';
  }
  if (status >= 500) {
    return 'The AI service is having trouble right now. Try again shortly.';
  }
  const detail = body.replace(/\s+/g, ' ').slice(0, 160);
  return `Request failed (${status}).${detail ? ` ${detail}` : ''}`;
}

/**
 * One non-streaming chat completion against an OpenAI-compatible endpoint.
 * The key is the user's own, entered in Settings and kept in the device keychain.
 */
export async function requestReply(settings: AiSettings, history: Turn[]): Promise<string> {
  const base = settings.baseUrl.trim().replace(/\/+$/, '');
  if (!base) throw new Error('No base URL set. Open Settings and add one.');
  if (!settings.model.trim()) throw new Error('No model set. Open Settings and add one.');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30_000);
  try {
    const response = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${settings.apiKey}`,
      },
      body: JSON.stringify({
        model: settings.model.trim(),
        messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...history],
        temperature: 0.7,
      }),
      signal: controller.signal,
    });

    if (!response.ok) {
      const body = await response.text().catch(() => '');
      throw new Error(describeHttpError(response.status, body));
    }

    const data = (await response.json()) as {
      choices?: { message?: { content?: string | null } }[];
    };
    const text = data.choices?.[0]?.message?.content?.trim();
    if (!text) throw new Error('The model returned an empty reply. Try sending again.');
    return text;
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      throw new Error('The request timed out. Check your connection and try again.');
    }
    if (error instanceof TypeError) {
      throw new Error('Could not reach the AI service. Check your connection and the base URL.');
    }
    throw error instanceof Error ? error : new Error('Something went wrong.');
  } finally {
    clearTimeout(timer);
  }
}
