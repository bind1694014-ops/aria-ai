/**
 * Replies used when no API key is connected. They are clearly labelled as demo replies in
 * the UI, so nobody mistakes them for a real model answer.
 */
const DEMO_NOTE = 'Demo reply — no AI key is connected yet. Open Settings to add one and get real answers.';

const SAMPLES: { match: RegExp; body: string }[] = [
  {
    match: /hello|hi\b|hey|salam|assalam/i,
    body: 'Hi! This is where a real answer would appear. Once you connect a key, I can chat about anything — questions, ideas, planning, writing, code.',
  },
  {
    match: /plan|schedule|todo|task|organi[sz]e/i,
    body: 'A simple way to plan: list everything on your mind, mark the one thing that matters most today, and give it a fixed time block. Everything else waits its turn.',
  },
  {
    match: /write|email|message|draft|letter/i,
    body: 'A good short message has three parts: why you are writing, the one thing you need, and when you need it. Keep it under five sentences and it usually gets answered faster.',
  },
  {
    match: /code|bug|error|program|javascript|python/i,
    body: 'When debugging, change one thing at a time and read the error from the bottom up — the last line usually names the real cause. Reproduce it in the smallest possible example.',
  },
  {
    match: /idea|brainstorm|creative/i,
    body: 'Try generating ten deliberately bad ideas first. Bad ideas are easy, and two or three of them usually point at a good one you would not have reached directly.',
  },
];

const FALLBACK =
  'This is a sample answer so you can see how the chat looks. Connect your own AI key in Settings and every message here gets a real reply from the model you choose.';

export function demoReply(prompt: string): string {
  const hit = SAMPLES.find((sample) => sample.match.test(prompt));
  return `${DEMO_NOTE}\n\n${hit ? hit.body : FALLBACK}`;
}
