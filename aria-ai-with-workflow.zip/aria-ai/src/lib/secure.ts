import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

/**
 * The user's own API key. On the phone it lives in the OS keychain (expo-secure-store);
 * the web preview has no keychain, so it falls back to local storage there.
 * The key is never bundled into the app and never leaves the device except to the
 * endpoint the user configured.
 */
const KEY = 'aria.apiKey';

export async function getApiKey(): Promise<string> {
  try {
    if (Platform.OS === 'web') return (await AsyncStorage.getItem(KEY)) ?? '';
    return (await SecureStore.getItemAsync(KEY)) ?? '';
  } catch {
    return '';
  }
}

export async function saveApiKey(value: string): Promise<void> {
  const trimmed = value.trim();
  if (Platform.OS === 'web') {
    if (trimmed) await AsyncStorage.setItem(KEY, trimmed);
    else await AsyncStorage.removeItem(KEY);
    return;
  }
  if (trimmed) await SecureStore.setItemAsync(KEY, trimmed);
  else await SecureStore.deleteItemAsync(KEY);
}
