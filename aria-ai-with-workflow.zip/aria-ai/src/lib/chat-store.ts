/** Chat data model and small helpers shared by the list and the chat screen. */

export type Role = 'user' | 'assistant';

export type Message = {
  id: string;
  role: Role;
  text: string;
  at: number;
  /** True when the reply came from the built-in demo responder, not a real model. */
  demo?: boolean;
};

export type Chat = {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
};

/** One key for every conversation, so the list and the chat screen stay in sync. */
export const CHATS_KEY = 'chats';

export function newId(): string {
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

export function createChat(): Chat {
  const now = Date.now();
  return { id: newId(), title: 'New chat', createdAt: now, updatedAt: now, messages: [] };
}

/** First user message becomes the conversation title. */
export function titleFrom(text: string): string {
  const clean = text.replace(/\s+/g, ' ').trim();
  if (clean.length <= 42) return clean || 'New chat';
  return `${clean.slice(0, 42).trimEnd()}…`;
}

export function preview(chat: Chat): string {
  const last = chat.messages[chat.messages.length - 1];
  if (!last) return 'No messages yet';
  const who = last.role === 'user' ? 'You: ' : '';
  const clean = last.text.replace(/\s+/g, ' ').trim();
  return `${who}${clean.length > 70 ? `${clean.slice(0, 70)}…` : clean}`;
}

/** Short relative time for the conversation list. */
export function formatWhen(ts: number): string {
  const diff = Date.now() - ts;
  const minute = 60_000;
  const hour = 60 * minute;
  const day = 24 * hour;
  if (diff < minute) return 'now';
  if (diff < hour) return `${Math.floor(diff / minute)}m`;
  if (diff < day) return `${Math.floor(diff / hour)}h`;
  if (diff < 7 * day) return `${Math.floor(diff / day)}d`;
  const d = new Date(ts);
  return `${d.getDate()}/${d.getMonth() + 1}`;
}
