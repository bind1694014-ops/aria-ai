import Ionicons from '@expo/vector-icons/Ionicons';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { EmptyState } from '@/components/ui';
import { spacing, useColors } from '@/constants/theme';
import { usePersistentState } from '@/hooks/use-persistent-state';
import { DEFAULT_BASE_URL, DEFAULT_MODEL, requestReply, type Turn } from '@/lib/ai';
import { CHATS_KEY, newId, titleFrom, type Chat, type Message } from '@/lib/chat-store';
import { demoReply } from '@/lib/demo';
import { getApiKey } from '@/lib/secure';

type Stored = { baseUrl: string; model: string };

const SUGGESTIONS = [
  'Explain something simply',
  'Help me plan my week',
  'Draft a short email',
  'Give me ideas for a project',
];

export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const [chats, setChats, status] = usePersistentState<Chat[]>(CHATS_KEY, []);
  const [settings] = usePersistentState<Stored>('aiSettings', {
    baseUrl: DEFAULT_BASE_URL,
    model: DEFAULT_MODEL,
  });

  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastPrompt, setLastPrompt] = useState<string | null>(null);
  const listRef = useRef<FlatList<Message>>(null);

  const chat = chats.find((c) => c.id === id);

  const scrollToEnd = useCallback(() => {
    requestAnimationFrame(() => listRef.current?.scrollToEnd({ animated: true }));
  }, []);

  useEffect(() => {
    if (chat && chat.messages.length > 0) scrollToEnd();
  }, [chat?.messages.length, scrollToEnd, chat]);

  /** Append messages to this conversation and keep its title/time in step. */
  const append = useCallback(
    (added: Message[], titleSource?: string) => {
      setChats((prev) =>
        prev.map((c) => {
          if (c.id !== id) return c;
          const messages = [...c.messages, ...added];
          return {
            ...c,
            messages,
            title:
              c.title === 'New chat' && titleSource ? titleFrom(titleSource) : c.title,
            updatedAt: Date.now(),
          };
        }),
      );
    },
    [id, setChats],
  );

  const send = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text || sending) return;

      const userMessage: Message = { id: newId(), role: 'user', text, at: Date.now() };
      const history: Turn[] = [
        ...(chat?.messages ?? []).map((m) => ({ role: m.role, content: m.text })),
        { role: 'user' as const, content: text },
      ];

      setDraft('');
      setError(null);
      setLastPrompt(text);
      setSending(true);
      append([userMessage], text);
      scrollToEnd();

      try {
        const apiKey = await getApiKey();
        let reply: string;
        let demo = false;
        if (apiKey.trim()) {
          reply = await requestReply(
            {
              apiKey: apiKey.trim(),
              baseUrl: settings.baseUrl || DEFAULT_BASE_URL,
              model: settings.model || DEFAULT_MODEL,
            },
            history,
          );
        } else {
          // No key yet: answer with a clearly labelled sample so the flow is visible.
          await new Promise((resolve) => setTimeout(resolve, 500));
          reply = demoReply(text);
          demo = true;
        }
        append([{ id: newId(), role: 'assistant', text: reply, at: Date.now(), demo }]);
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Something went wrong. Try again.');
      } finally {
        setSending(false);
        scrollToEnd();
      }
    },
    [append, chat?.messages, scrollToEnd, sending, settings.baseUrl, settings.model],
  );

  function retry() {
    if (!lastPrompt) return;
    setError(null);
    void send(lastPrompt);
  }

  if (status === 'loading') {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  if (!chat) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <EmptyState
          icon="chatbubble-outline"
          title="Chat not found"
          message="This conversation was deleted or never existed."
          actionTitle="Back to chats"
          onAction={() => router.replace('/')}
        />
      </View>
    );
  }

  const messages = chat.messages;

  return (
    <KeyboardAvoidingView
      style={[styles.root, { backgroundColor: colors.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 96 : 0}>
      <Stack.Screen options={{ title: chat.title === 'New chat' ? 'New chat' : chat.title }} />

      {messages.length === 0 ? (
        <View style={styles.intro}>
          <View style={[styles.heroIcon, { backgroundColor: colors.accentSoft }]}>
            <Ionicons name="sparkles" size={30} color={colors.primary} />
          </View>
          <Text style={[styles.heroTitle, { color: colors.text }]}>How can I help?</Text>
          <Text style={[styles.heroBody, { color: colors.muted }]}>
            Ask a question, get help with a task, or just have a conversation.
          </Text>
          <View style={styles.chips}>
            {SUGGESTIONS.map((s) => (
              <Pressable
                key={s}
                accessibilityRole="button"
                onPress={() => void send(s)}
                style={({ pressed }) => [
                  styles.chip,
                  { backgroundColor: colors.card, borderColor: colors.border },
                  pressed && { opacity: 0.7 },
                ]}>
                <Text style={[styles.chipText, { color: colors.text }]}>{s}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      ) : (
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          keyboardShouldPersistTaps="handled"
          onContentSizeChange={scrollToEnd}
          renderItem={({ item }) => {
            const mine = item.role === 'user';
            return (
              <View style={[styles.bubbleRow, mine ? styles.rowMine : styles.rowTheirs]}>
                {!mine ? (
                  <View style={[styles.miniAvatar, { backgroundColor: colors.accentSoft }]}>
                    <Ionicons name="sparkles" size={13} color={colors.primary} />
                  </View>
                ) : null}
                <View
                  style={[
                    styles.bubble,
                    mine
                      ? [styles.bubbleMine, { backgroundColor: colors.bubbleUser }]
                      : [styles.bubbleTheirs, { backgroundColor: colors.bubbleAi, borderColor: colors.border }],
                  ]}>
                  <Text
                    selectable
                    style={[
                      styles.bubbleText,
                      { color: mine ? colors.bubbleUserText : colors.bubbleAiText },
                    ]}>
                    {item.text}
                  </Text>
                  {item.demo ? (
                    <View style={styles.demoTag}>
                      <Ionicons
                        name="information-circle-outline"
                        size={12}
                        color={mine ? colors.bubbleUserText : colors.muted}
                      />
                      <Text
                        style={[
                          styles.demoText,
                          { color: mine ? colors.bubbleUserText : colors.muted },
                        ]}>
                        Sample reply
                      </Text>
                    </View>
                  ) : null}
                </View>
              </View>
            );
          }}
          ListFooterComponent={
            sending ? (
              <View style={[styles.bubbleRow, styles.rowTheirs]}>
                <View style={[styles.miniAvatar, { backgroundColor: colors.accentSoft }]}>
                  <Ionicons name="sparkles" size={13} color={colors.primary} />
                </View>
                <View
                  style={[
                    styles.bubble,
                    styles.bubbleTheirs,
                    styles.typing,
                    { backgroundColor: colors.bubbleAi, borderColor: colors.border },
                  ]}>
                  <ActivityIndicator size="small" color={colors.muted} />
                  <Text style={[styles.typingText, { color: colors.muted }]}>Thinking…</Text>
                </View>
              </View>
            ) : null
          }
        />
      )}

      {error ? (
        <View style={[styles.errorBar, { backgroundColor: colors.card, borderColor: colors.danger }]}>
          <Ionicons name="alert-circle" size={16} color={colors.danger} />
          <Text style={[styles.errorText, { color: colors.danger }]}>{error}</Text>
          <Pressable accessibilityRole="button" onPress={retry} hitSlop={8}>
            <Text style={[styles.retry, { color: colors.primary }]}>Retry</Text>
          </Pressable>
        </View>
      ) : null}

      <View
        style={[
          styles.composer,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
            paddingBottom: Math.max(insets.bottom, spacing.sm),
          },
        ]}>
        <TextInput
          value={draft}
          onChangeText={setDraft}
          placeholder="Message Aria…"
          placeholderTextColor={colors.muted}
          accessibilityLabel="Message"
          multiline
          maxLength={4000}
          style={[styles.input, { color: colors.text, backgroundColor: colors.background }]}
        />
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Send message"
          accessibilityState={{ disabled: !draft.trim() || sending }}
          disabled={!draft.trim() || sending}
          onPress={() => void send(draft)}
          style={({ pressed }) => [
            styles.sendButton,
            { backgroundColor: draft.trim() && !sending ? colors.primary : colors.border },
            pressed && { opacity: 0.75 },
          ]}>
          <Ionicons
            name="arrow-up"
            size={20}
            color={draft.trim() && !sending ? colors.onPrimary : colors.muted}
          />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  intro: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.lg, gap: spacing.sm },
  heroIcon: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
  heroTitle: { fontSize: 24, fontWeight: '700', marginTop: spacing.sm },
  heroBody: { fontSize: 15, lineHeight: 21, textAlign: 'center', maxWidth: 300 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: spacing.sm, marginTop: spacing.md },
  chip: { paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: 20, borderWidth: StyleSheet.hairlineWidth },
  chipText: { fontSize: 14 },
  list: { padding: spacing.md, gap: spacing.sm, paddingBottom: spacing.lg },
  bubbleRow: { flexDirection: 'row', alignItems: 'flex-end', gap: spacing.xs, maxWidth: '100%' },
  rowMine: { justifyContent: 'flex-end' },
  rowTheirs: { justifyContent: 'flex-start' },
  miniAvatar: { width: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 2 },
  bubble: { maxWidth: '82%', paddingHorizontal: spacing.md, paddingVertical: 10, borderRadius: 18 },
  bubbleMine: { borderBottomRightRadius: 6 },
  bubbleTheirs: { borderBottomLeftRadius: 6, borderWidth: StyleSheet.hairlineWidth },
  bubbleText: { fontSize: 16, lineHeight: 22 },
  demoTag: { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 6 },
  demoText: { fontSize: 11 },
  typing: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  typingText: { fontSize: 14 },
  errorBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
    padding: spacing.sm,
    borderRadius: 12,
    borderWidth: 1,
  },
  errorText: { flex: 1, fontSize: 13, lineHeight: 18 },
  retry: { fontSize: 13, fontWeight: '700' },
  composer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  input: {
    flex: 1,
    minHeight: 44,
    maxHeight: 120,
    borderRadius: 22,
    paddingHorizontal: spacing.md,
    paddingTop: 12,
    paddingBottom: 12,
    fontSize: 16,
  },
  sendButton: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
});
