import Ionicons from '@expo/vector-icons/Ionicons';
import { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import { Button, Card, ConfirmDialog, TextField } from '@/components/ui';
import { spacing, useColors } from '@/constants/theme';
import { usePersistentState } from '@/hooks/use-persistent-state';
import { DEFAULT_BASE_URL, DEFAULT_MODEL, requestReply } from '@/lib/ai';
import { CHATS_KEY, type Chat } from '@/lib/chat-store';
import { getApiKey, saveApiKey } from '@/lib/secure';

type Stored = { baseUrl: string; model: string };

const DEFAULTS: Stored = { baseUrl: DEFAULT_BASE_URL, model: DEFAULT_MODEL };

export default function SettingsScreen() {
  const colors = useColors();
  const [stored, setStored, storedStatus] = usePersistentState<Stored>('aiSettings', DEFAULTS);
  const [, setChats] = usePersistentState<Chat[]>(CHATS_KEY, []);

  const [key, setKey] = useState('');
  const [baseUrl, setBaseUrl] = useState(DEFAULTS.baseUrl);
  const [model, setModel] = useState(DEFAULTS.model);
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [notice, setNotice] = useState<{ tone: 'ok' | 'bad'; text: string } | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  useEffect(() => {
    let alive = true;
    getApiKey().then((value) => {
      if (!alive) return;
      setKey(value);
      setLoaded(true);
    });
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (storedStatus !== 'ready') return;
    setBaseUrl(stored.baseUrl || DEFAULT_BASE_URL);
    setModel(stored.model || DEFAULT_MODEL);
  }, [storedStatus, stored.baseUrl, stored.model]);

  async function save() {
    setSaving(true);
    setNotice(null);
    try {
      await saveApiKey(key);
      setStored({ baseUrl: baseUrl.trim() || DEFAULT_BASE_URL, model: model.trim() || DEFAULT_MODEL });
      setNotice({ tone: 'ok', text: key.trim() ? 'Saved. New messages will use this key.' : 'Key removed. The app is back in demo mode.' });
    } catch {
      setNotice({ tone: 'bad', text: 'Could not save the key on this device.' });
    } finally {
      setSaving(false);
    }
  }

  async function test() {
    setTesting(true);
    setNotice(null);
    try {
      const reply = await requestReply(
        { apiKey: key.trim(), baseUrl: baseUrl.trim() || DEFAULT_BASE_URL, model: model.trim() || DEFAULT_MODEL },
        [{ role: 'user', content: 'Reply with the single word: ready' }],
      );
      setNotice({ tone: 'ok', text: `Connected. The model replied: “${reply.slice(0, 60)}”` });
    } catch (error) {
      setNotice({ tone: 'bad', text: error instanceof Error ? error.message : 'Connection failed.' });
    } finally {
      setTesting(false);
    }
  }

  function clearChats() {
    setConfirmClear(false);
    setChats([]);
    setNotice({ tone: 'ok', text: 'All conversations were deleted from this phone.' });
  }

  const connected = key.trim().length > 0;

  return (
    <Screen>
      <Card>
        <View style={styles.statusRow}>
          <View
            style={[
              styles.dot,
              { backgroundColor: connected ? colors.primary : colors.muted },
            ]}
          />
          <Text style={[styles.statusText, { color: colors.text }]}>
            {connected ? 'Connected to your AI key' : 'Demo mode — no key connected'}
          </Text>
        </View>
        <Text style={[styles.body, { color: colors.muted }]}>
          {connected
            ? 'Messages are sent straight from this phone to the endpoint below, using your own key. Nothing passes through a server of ours.'
            : 'Without a key, replies are clearly labelled samples. Add a key from any OpenAI-compatible provider to get real answers.'}
        </Text>
      </Card>

      <Card>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Your AI connection</Text>
        {!loaded ? (
          <ActivityIndicator color={colors.primary} />
        ) : (
          <>
            <TextField
              label="API key"
              value={key}
              onChangeText={setKey}
              placeholder="sk-..."
              autoCapitalize="none"
              autoCorrect={false}
              secureTextEntry
              hint="Stored in this phone's secure keychain. Never uploaded anywhere else."
            />
            <TextField
              label="Base URL"
              value={baseUrl}
              onChangeText={setBaseUrl}
              placeholder={DEFAULT_BASE_URL}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
              hint="OpenAI, Groq, OpenRouter and others all work — use their /v1 address."
            />
            <TextField
              label="Model"
              value={model}
              onChangeText={setModel}
              placeholder={DEFAULT_MODEL}
              autoCapitalize="none"
              autoCorrect={false}
              hint="For example gpt-4o-mini, llama-3.3-70b-versatile, or a model name from your provider."
            />
            <View style={styles.actions}>
              <View style={styles.action}>
                <Button title="Save" icon="checkmark" onPress={save} loading={saving} />
              </View>
              <View style={styles.action}>
                <Button
                  title="Test"
                  variant="secondary"
                  icon="pulse"
                  onPress={test}
                  loading={testing}
                  disabled={!connected}
                />
              </View>
            </View>
            {notice ? (
              <View style={styles.noticeRow}>
                <Ionicons
                  name={notice.tone === 'ok' ? 'checkmark-circle' : 'alert-circle'}
                  size={16}
                  color={notice.tone === 'ok' ? colors.primary : colors.danger}
                />
                <Text
                  style={[
                    styles.notice,
                    { color: notice.tone === 'ok' ? colors.muted : colors.danger },
                  ]}>
                  {notice.text}
                </Text>
              </View>
            ) : null}
          </>
        )}
      </Card>

      <Card>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Your data</Text>
        <Text style={[styles.body, { color: colors.muted }]}>
          Conversations are saved on this phone only. Deleting them cannot be undone.
        </Text>
        <Button
          title="Delete all conversations"
          variant="secondary"
          icon="trash-outline"
          onPress={() => setConfirmClear(true)}
        />
      </Card>

      <Text style={[styles.footer, { color: colors.muted }]}>
        Aria AI · your own key, your own data
      </Text>

      <ConfirmDialog
        visible={confirmClear}
        title="Delete all conversations?"
        message="Every chat and message on this phone will be removed. This cannot be undone."
        confirmTitle="Delete all"
        cancelTitle="Cancel"
        destructive
        onConfirm={clearChats}
        onCancel={() => setConfirmClear(false)}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  dot: { width: 9, height: 9, borderRadius: 5 },
  statusText: { fontSize: 16, fontWeight: '600' },
  body: { fontSize: 14, lineHeight: 20 },
  sectionTitle: { fontSize: 17, fontWeight: '700' },
  actions: { flexDirection: 'row', gap: spacing.sm },
  action: { flex: 1 },
  noticeRow: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.xs },
  notice: { flex: 1, fontSize: 13, lineHeight: 18 },
  footer: { fontSize: 12, textAlign: 'center', marginTop: spacing.sm },
});
