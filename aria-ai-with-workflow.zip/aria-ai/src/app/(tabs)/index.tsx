import Ionicons from '@expo/vector-icons/Ionicons';
import { router } from 'expo-router';
import { useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';

import { Screen } from '@/components/screen';
import { ConfirmDialog, EmptyState } from '@/components/ui';
import { spacing, useColors } from '@/constants/theme';
import { usePersistentState } from '@/hooks/use-persistent-state';
import {
  CHATS_KEY,
  createChat,
  formatWhen,
  preview,
  type Chat,
} from '@/lib/chat-store';

export default function ChatsScreen() {
  const colors = useColors();
  const [chats, setChats, status] = usePersistentState<Chat[]>(CHATS_KEY, []);
  const [pendingDelete, setPendingDelete] = useState<Chat | null>(null);

  const sorted = [...chats].sort((a, b) => b.updatedAt - a.updatedAt);

  function startChat() {
    const chat = createChat();
    setChats((prev) => [chat, ...prev]);
    router.push({ pathname: '/chat/[id]', params: { id: chat.id } });
  }

  function confirmDelete() {
    const target = pendingDelete;
    setPendingDelete(null);
    if (!target) return;
    setChats((prev) => prev.filter((c) => c.id !== target.id));
  }

  return (
    <Screen scroll={false}>
      <View style={styles.header}>
        <View style={styles.headerText}>
          <Text style={[styles.title, { color: colors.text }]}>Chats</Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>
            {sorted.length === 0
              ? 'Talk to Aria about anything'
              : `${sorted.length} conversation${sorted.length === 1 ? '' : 's'}`}
          </Text>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Start a new chat"
          onPress={startChat}
          style={({ pressed }) => [
            styles.newButton,
            { backgroundColor: colors.primary },
            pressed && { opacity: 0.75 },
          ]}>
          <Ionicons name="add" size={22} color={colors.onPrimary} />
          <Text style={[styles.newLabel, { color: colors.onPrimary }]}>New</Text>
        </Pressable>
      </View>

      {status === 'loading' ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : status === 'error' ? (
        <EmptyState
          icon="alert-circle-outline"
          title="Could not load your chats"
          message="Your saved conversations could not be read on this device."
        />
      ) : sorted.length === 0 ? (
        <EmptyState
          icon="chatbubble-ellipses-outline"
          title="No chats yet"
          message="Ask a question, get help with a task, or just say hello."
          actionTitle="Start a chat"
          onAction={startChat}
        />
      ) : (
        <FlatList
          data={sorted}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <Pressable
              accessibilityRole="button"
              onPress={() => router.push({ pathname: '/chat/[id]', params: { id: item.id } })}
              onLongPress={() => setPendingDelete(item)}
              style={({ pressed }) => [
                styles.row,
                { backgroundColor: colors.card, borderColor: colors.border },
                pressed && { opacity: 0.75 },
              ]}>
              <View style={[styles.avatar, { backgroundColor: colors.accentSoft }]}>
                <Ionicons name="sparkles" size={18} color={colors.primary} />
              </View>
              <View style={styles.rowText}>
                <View style={styles.rowTop}>
                  <Text numberOfLines={1} style={[styles.rowTitle, { color: colors.text }]}>
                    {item.title}
                  </Text>
                  <Text style={[styles.when, { color: colors.muted }]}>
                    {formatWhen(item.updatedAt)}
                  </Text>
                </View>
                <Text numberOfLines={1} style={[styles.rowPreview, { color: colors.muted }]}>
                  {preview(item)}
                </Text>
              </View>
            </Pressable>
          )}
        />
      )}

      <ConfirmDialog
        visible={pendingDelete !== null}
        title="Delete this chat?"
        message={pendingDelete ? `“${pendingDelete.title}” and its messages will be removed from this phone.` : undefined}
        confirmTitle="Delete"
        cancelTitle="Cancel"
        destructive
        onConfirm={confirmDelete}
        onCancel={() => setPendingDelete(null)}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
  },
  headerText: { flex: 1, gap: 2 },
  title: { fontSize: 28, fontWeight: '700', letterSpacing: -0.5 },
  subtitle: { fontSize: 14 },
  newButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    paddingHorizontal: spacing.md,
    height: 44,
    borderRadius: 22,
  },
  newLabel: { fontSize: 15, fontWeight: '600' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  list: { paddingHorizontal: spacing.md, paddingBottom: spacing.xl, gap: spacing.sm },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
  },
  avatar: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  rowText: { flex: 1, gap: 3 },
  rowTop: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  rowTitle: { flex: 1, fontSize: 16, fontWeight: '600' },
  when: { fontSize: 12 },
  rowPreview: { fontSize: 14 },
});
