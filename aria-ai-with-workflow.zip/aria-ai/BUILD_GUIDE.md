# Aria AI — how to get the app on your phone

This folder is the complete source code of **Aria AI**, an AI agent chat app
(Expo / React Native, package id `com.aria.aiagent`).

It was not built into an installable file here: an Android or iOS app has to be built and
signed by a build service, and that build is yours, under your own free Expo account.

You need a computer (Windows, macOS or Linux) with **Node.js 20 or newer**
(https://nodejs.org) for the steps below. No Android Studio, Java or Mac is needed.

---

## 1. Android: get an installable APK (free)

1. Create a free account at https://expo.dev/signup.
2. Unzip this folder, open a terminal inside it, and run:

   ```bash
   npm install
   npm install -g eas-cli
   eas login
   eas init
   eas build --platform android --profile preview
   ```

   - `eas init` links the project to your account the first time; answer **Yes**.
   - When asked to generate a new Android keystore, answer **Yes**. Expo stores it for you,
     so every later build is signed with the same key and installs as an update.
3. The build runs in Expo's cloud. Free accounts wait in a low-priority queue, which at
   busy times can take over an hour.
   When it finishes, the terminal and the page on expo.dev show a link and a QR code.
   Open it on your Android phone, download the `.apk` and install it (allow "install
   unknown apps" for your browser when Android asks).

The free plan includes a limited number of builds per month (about 15 Android builds,
see https://expo.dev/pricing).

---

## 2. Try it on your phone before building (optional, 2 minutes)

1. Install **Expo Go** from the Play Store on your Android phone.
2. In the project folder on your computer run:

   ```bash
   npm install
   npx expo start
   ```

3. Scan the QR code shown in the terminal with Expo Go (Android) or the Camera app (iPhone).
   The app opens on your phone. This is the fastest way to check the chat screen, the
   bubbles and the input before you spend a build.

---

## 3. Connect a real AI model

The app ships in **demo mode**: without a key, replies are clearly labelled sample answers
so you can see the whole flow. To get real answers:

1. Open the app → **Settings** tab.
2. Fill in:
   - **API key** — your own key from any OpenAI-compatible provider
     (OpenAI, Groq, OpenRouter, Together, a local gateway, …).
   - **Base URL** — the provider's `/v1` address, e.g.
     `https://api.openai.com/v1` (OpenAI), `https://api.groq.com/openai/v1` (Groq),
     `https://openrouter.ai/api/v1` (OpenRouter).
   - **Model** — e.g. `gpt-4o-mini`, `llama-3.3-70b-versatile`, or any model your
     provider offers.
3. Tap **Save**, then **Test**. A green "Connected" message means the key works.

How the key is handled:

- It is stored in the phone's secure keychain (`expo-secure-store`), not in the app bundle.
- It is sent only to the base URL you entered, straight from the phone. There is no server
  of ours in between.
- Anyone using the app must enter their own key. Never hard-code a key into the source:
  anything inside the app can be read by whoever installs it.

If you later want the key to live on a server instead (so users don't need their own), you
would add a small backend that holds the key and forwards requests — the app's
`src/lib/ai.ts` is the single place to change.

---

## 4. What the app does

- **Chats tab** — every conversation, newest first, with a preview and relative time.
  Tap to open, long-press to delete. The **New** button starts a fresh chat.
- **Chat screen** — message bubbles (yours on the right, Aria's on the left), a typing
  indicator, an error bar with **Retry**, and a composer with a send button that grows with
  your text. Empty chats show four starter prompts.
- **Settings tab** — AI connection (key, base URL, model, test), and "delete all
  conversations".
- Conversations are saved on the phone only (AsyncStorage) and survive app restarts.
- Light and dark mode follow the phone's system setting.

Source layout:

```
src/app/(tabs)/index.tsx      conversation list
src/app/(tabs)/settings.tsx   AI connection + data
src/app/chat/[id].tsx         the chat screen
src/lib/ai.ts                 the model request (OpenAI-compatible)
src/lib/chat-store.ts         chat/message types and helpers
src/lib/secure.ts             keychain storage for the API key
src/lib/demo.ts               labelled sample replies used without a key
```

---

## 5. iPhone and the app stores (optional)

- **iPhone** needs an Apple Developer Program membership (99 USD/year). Then run
  `eas build --platform ios --profile production` and `eas submit --platform ios`, and
  install it through TestFlight. Details: https://docs.expo.dev/submit/ios/
- **Google Play** needs a developer account (one-time 25 USD). Then run
  `eas build --platform android --profile production` and `eas submit --platform android`.
  Details: https://docs.expo.dev/submit/android/

---

## 6. Settings you may need to fill in

- `app.json` → `name` (shown under the icon), `version`, and the icon files in
  `assets/images/`. Bump `version` every time you ship a change.
- `.env.example` → copy to `.env` and fill in `EXPO_PUBLIC_API_URL` only if you add a
  backend. Values in `.env` are bundled into the app and readable by anyone who has it:
  never put passwords or secret keys there.

---

## 7. What was and was not checked

Checked before delivery: the code type-checks and the Android JavaScript bundle compiles.

Not checked: running on a real device, and a real model call (that needs your key). Test
the installed app before sharing it, and report anything that misbehaves together with a
screenshot.
